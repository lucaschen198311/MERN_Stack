import React, { useState } from 'react';

export default (props) => {
    // Initial values of the fields (empty if adding, retrieved values if updating), plus a function that will handle
    // adding or submitting depending on what's happening, are passed through props
    const { initialName, initialPosition, errorVals, onSubmitFunc } = props;
    // Fields are shown below; useState hook helps us keep track of what's being typed
    const [name, setName] = useState(initialName); 
    const [position, setPosition] = useState(initialPosition);

    const onSubmitHandler = (e) => {
        e.preventDefault(); // Stop form from submitting like normal - we'll do it ourselves
        onSubmitFunc({name, position}); // Handle the new values (post or put depending on adding/updating)
    }

    return(
        <form onSubmit={onSubmitHandler}>
            <p>
                <label htmlFor="name">Name:</label><br/>
                <input type="text" onChange = {(e)=>setName(e.target.value)} value={name}/><br/>
                {errorVals?.name && <span style={{color: "red"}}>{errorVals.name?.message}</span>}
            </p>
            <p>
                <label htmlFor="position">Position:</label><br/>
                <input type="text" onChange = {(e)=>setPosition(e.target.value)} value={position}/>
            </p>
            <button type="submit" disabled={name !== undefined && name.length < 2 ? true : false}>Submit</button>
        </form>
    );
}