import { Link, navigate } from '@reach/router';
import React, { useEffect, useState } from 'react';
import axios from 'axios';

export default (props) => {
    const { game_num } = props;
    const [ isLoaded, setIsLoaded ] = useState(false);
    const [ players, setPlayers ] = useState([]);
    const [ errors, setErrors ] = useState({});
    
    // Get list of players - only need to do that once
    useEffect(()=>{
        axios.get("http://localhost:8000/api/players")
            .then(res=>{
                setPlayers(res.data); // Get list of players and set it
                setIsLoaded(true); // Data loaded successfully  
            })       
    }, [players]);

    const redStyle = {
        backgroundColor: "red",
        color: "white"
    };
    
    const yellowStyle = {
        backgroundColor: "yellow",
        color: "black"
    };

    const greenStyle = {
        backgroundColor: "green",
        color: "white"
    };

    const notSelectedStyle = {
        backgroundColor: "white",
        color: "black"
    }

    const boldStyle = {
        fontWeight: "bold"
    }

    const changeGameStatus = (e, statusNum, ind) => {
        e.preventDefault();
        // Find current player in question
        const curPlayer = players[ind];
        console.log(curPlayer);
        curPlayer.gamesAvailability[game_num-1] = statusNum; // Change status number
        
        // Save change into database
        axios.put('http://localhost:8000/api/players/' + curPlayer._id, curPlayer)
        .then(res => {
            console.log("Change successful");
            console.log(res);
            let newPlayerArr = [...players]; // Spread operator needed for making a NEW array for setting
            newPlayerArr[ind] = curPlayer; // Store the newly modified player
            setPlayers(newPlayerArr); // Save the new players array
        })
        .catch(err=> {
            console.log("Errors found");
            const errorResponse = err.response.data.errors; // Get the errors from err.response.data
            // Set Errors
            setErrors(errorResponse);
        });
    }

    // Placeholder page when loading
    if (!isLoaded) {
        return <h2>Loading players and page...</h2>;
    }

    if (game_num != 1 && game_num != 2 && game_num != 3) { // If game number is not valid 
        navigate("/error"); // Send to 404 page
    }
    return (
        <div>
            <h1>Player status - Game {game_num}</h1>
            <p><Link to="/players/list">Manage players</Link> | Manage player status</p>
            <p>
                <Link style={game_num === 1 ? boldStyle : {}} to="/status/game/1">Game 1</Link> | <Link to="/status/game/2"><span style={game_num === 2 ? boldStyle : {}}>Game 2</span></Link> | <Link to="/status/game/3"><span style={game_num === 3 ? boldStyle : {}}>Game 3</span></Link>
            </p>
            <table>
                <thead>
                    <tr>
                        <th>Player name</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {players.map((player, ind) => {
                        return (
                            <tr key={ind}>
                                <td><Link to={"/players/edit/"+player._id}>{player.name}</Link></td>
                                <td>
                                    <button onClick={e => {changeGameStatus(e,-1,ind)}} style={player.gamesAvailability[game_num-1] === -1 ? redStyle : notSelectedStyle}>Not playing</button> 
                                    <button onClick={e => {changeGameStatus(e,0,ind)}} style={player.gamesAvailability[game_num-1] === 0 ? yellowStyle : notSelectedStyle}>Undecided</button> 
                                    <button onClick={e => {changeGameStatus(e,1,ind)}} style={player.gamesAvailability[game_num-1] === 1 ? greenStyle : notSelectedStyle}>Playing</button>
                                </td>
                            </tr>
                        );
                    })}
                </tbody>
            </table>
        </div>
    )
}