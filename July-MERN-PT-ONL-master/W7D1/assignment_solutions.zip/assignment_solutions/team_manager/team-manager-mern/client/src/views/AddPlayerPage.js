import React, { useState } from 'react';
import PlayerForm from '../components/PlayerForm';
import axios from 'axios';
import { navigate } from '@reach/router';

export default (props) => {
    const [errors, setErrors] = useState({});

    const createPlayer = (player) => {
        axios.post('http://localhost:8000/api/players', player)
            .then(res=> {
                console.log("Successful submission");
                console.log(res);
                // navigate("/players/list");
                navigate("/");
            })
            .catch(err=> {
                const errorResponse = err.response.data.errors; // Get the errors from err.response.data
                // Set Errors
                setErrors(errorResponse);
            });
    }

    return (
        <div>
            <h1>Players</h1>
            <h3 style={{color: "purple"}}>Add a player:</h3>
            <PlayerForm initialName="" initialPosition="" onSubmitFunc={createPlayer} errorVals={errors}/>
            
        </div>
    );
}