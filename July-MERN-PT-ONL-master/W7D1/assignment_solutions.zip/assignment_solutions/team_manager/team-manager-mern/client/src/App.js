import React from 'react';
import './App.css';
import {Redirect, Router} from '@reach/router';
import AddPlayerPage from './views/AddPlayerPage';
import PlayerList from './views/PlayerList';
import ErrorPage from './views/ErrorPage';
import EditPlayerPage from './views/EditPlayerPage';
import GamePage from './views/GamePage';

function App() {
    return (
        <div className="App">
            <Router>
                <Redirect from="/" to="/players/list" noThrow="true" />
                <Redirect from="/players" to="/players/list" noThrow="true" />
                <PlayerList path="/players/list" />
                <AddPlayerPage path="/players/addplayer" />
                <EditPlayerPage path="/players/edit/:id" />
                <Redirect from="/status" to="/status/game/1" noThrow="true" />
                <GamePage path="/status/game/:game_num" />
                <ErrorPage default path="/error"/>
            </Router>
        </div>
    );
}

export default App;
