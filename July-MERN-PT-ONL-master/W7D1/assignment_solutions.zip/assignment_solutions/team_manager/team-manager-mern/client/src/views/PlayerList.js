import React, { useEffect, useState } from 'react'
import axios from 'axios';
import { Link, navigate } from '@reach/router';
export default () => {
    const [ isLoaded, setIsLoaded ] = useState(false);
    const [ players, setPlayers ] = useState([]);
    useEffect(()=>{
        axios.get("http://localhost:8000/api/players")
            .then(res=>{
                setPlayers(res.data); // Get list of players and set it
                setIsLoaded(true); // Data loaded successfully   
            })       
    }, []);
    
    // Function that handles "Delete" button
    const deletePlayer = (e, playerId) => {
        axios.delete('http://localhost:8000/api/players/' + playerId)
            .then(res=>{
                setPlayers(players.filter(player => player._id !== playerId));
            })
    }

    // Placeholder page when loading
    if (!isLoaded) {
        return <h2>Loading players and page...</h2>;
    }
    
    return (
        <div>
            <h1>Players</h1>
            <p>Manage players | <Link to="/status/game/1">Manage player status</Link></p>
            <Link to="/players/addplayer">
                Add Player
            </Link>
            <table>
                <thead>
                    <tr>
                        <th>Player name</th>
                        <th>Preferred position</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {players.map((player, ind) => {
                        return (
                            <tr key={ind}>
                                <td><Link to={"/players/edit/"+player._id}>{player.name}</Link></td>
                                <td>{player.position}</td>
                                <td>
                                    <button style={{backgroundColor: "red", color: "white"}}onClick={e => {deletePlayer(e,player._id)}}>Delete</button>
                                </td>
                            </tr>
                        );
                    })}
                </tbody>
            </table>
        </div>
    )
}