import React, { useEffect, useState } from 'react'
import axios from 'axios';
import { navigate } from '@reach/router'; // Link
import PlayerForm from '../components/PlayerForm';
export default props => {
    const { id } = props;
    const [player, setPlayer] = useState([]); // Now use entire object instead of each field
    const [loaded, setLoaded] = useState(false); // For making sure item is actually loaded
    const [errors, setErrors] = useState({});
    const [isFound, setIsFound] = useState(false);
    useEffect(() => {
        axios.get('http://localhost:8000/api/players/' + id)
            .then(res => {
                setPlayer(res.data); // Get data from the item instead of setting each field individually
                setIsFound(true);
                setLoaded(true); // Player is loaded successfully
            })
            .catch(err => {
                console.log("Not found");
                setLoaded(true); // Page loaded - but error found, so isFound will become false
                setIsFound(false);
                console.log(err);
            })
    }, [id])

    const updatePlayer = (player) => { // Change from (e) to (player); also player is included in put arguments below
        // e.preventDefault(); // Form component will do it for us now
        axios.put('http://localhost:8000/api/players/' + id, player)
            .then(res => {
                console.log("Edit successful");
                console.log(player.name);
                console.log(res);
                navigate('/'); // Redirect back to main page if successful
            })
            .catch(err=> {
                console.log("Errors found");
                const errorResponse = err.response.data.errors; // Get the errors from err.response.data
                console.log(player.name);
                // Set Errors
                setErrors(errorResponse);
            });
    }

    if (!loaded) { // Placeholder page for loading
        return <div>Loading this player....</div>;
    }

    if (!isFound) { // Not found - redirect to error 404 (not found) page 
        navigate('/error');
    }

    return ( // Note below: need {} and loaded variable to render the information from the database
        <div>
            <h1>Players</h1>
            <h3 style={{color: "purple"}}>Edit a player:</h3>
            {loaded && (
            <PlayerForm onSubmitFunc={updatePlayer} 
                initialName={player.name} 
                initialPosition={player.position}
                errorVals={errors}
            />
            )}
        </div>
    )
}