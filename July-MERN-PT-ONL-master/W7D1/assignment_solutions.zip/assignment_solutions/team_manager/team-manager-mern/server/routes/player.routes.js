const PlayerController = require('../controllers/player.controller');

module.exports = (app) => {
    // app.get('/api', PlayerController.index); // For testing
    app.get('/api/players',PlayerController.getAllPlayers); // List all players
    app.get('/api/players/:id',PlayerController.getPlayer); // List one player
    app.post('/api/players', PlayerController.createPlayer); // Add new player
    app.put('/api/players/:id',PlayerController.updatePlayer); // Update one player
    app.delete('/api/players/:id', PlayerController.deletePlayer); // Delete a player
}
