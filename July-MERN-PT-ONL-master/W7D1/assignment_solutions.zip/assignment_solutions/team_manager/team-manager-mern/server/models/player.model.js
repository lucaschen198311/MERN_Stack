const mongoose = require('mongoose');
const PlayerSchema = new mongoose.Schema({
    name: { 
        type: String,
        minlength: [2, "Name must be at least 2 characters"], // Must be at least 2 characters
        required: [true, "Name is required"] 
    },
    position: { type: String }, // Optional
    gamesAvailability: {
        type: Array,
        // Default value will be initialized upon creation of Player
        default: [0,0,0], // -1 = Not playing, 0 = Undecided, 1 = Playing
    }
}, { timestamps: true });
module.exports.Player = mongoose.model('Player', PlayerSchema);
